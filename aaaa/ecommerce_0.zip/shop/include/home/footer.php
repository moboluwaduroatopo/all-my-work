<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2014 Gadget Works. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="#">FBC Students</a></span></p>
				</div>
			</div>
		</div>
						
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/script.js"></script>
</body>
</html>